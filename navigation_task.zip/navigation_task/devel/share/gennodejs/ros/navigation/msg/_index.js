
"use strict";

let nav_output = require('./nav_output.js');
let nav_input = require('./nav_input.js');

module.exports = {
  nav_output: nav_output,
  nav_input: nav_input,
};
