#!/usr/bin/env python


import rospy
import math
from navigation.msg import nav_input
from navigation.msg import nav_output

msg_in = nav_input()
msg_out = nav_output()

x = 0
y = 0
theta = 0

def bicycle_model(msg):
    velocity = msg.velocity
    steer = msg.steering_angle
    beta = 0
    theta_dot = 0
    theta_dot_prev = 0
    lr = 0.5
    l = 1
    sample_time = 0.5
    global x, y , theta
    x_cg_dot = 0
    y_cg_dot = 0
    beta=math.atan((lr*(math.tan(steer)/l)))
    x_cg_dot=velocity*math.cos(theta+beta)
    y_cg_dot=(velocity*math.sin(theta+beta))
    theta_dot=velocity*math.cos(beta)*math.tan(steer)/l
    x +=x_cg_dot*sample_time
    y +=y_cg_dot*sample_time
    theta+=theta_dot*sample_time
    msg_out.x = x
    msg_out.y = y
    msg_out.orientation=theta



def callback(msg):
    bicycle_model(msg)



rospy.init_node('Navigation', anonymous=True)
sub = rospy.Subscriber("input", nav_input, callback)
pub = rospy.Publisher('output', nav_output, queue_size=10)
rate = rospy.Rate(1)
while not rospy.is_shutdown():
        rospy.loginfo("x= %f",msg_out.x)
        rospy.loginfo("y =  %f",msg_out.y)
        rospy.loginfo("orientation =  %f",msg_out.orientation)
        pub.publish(msg_out)
        rate.sleep()
