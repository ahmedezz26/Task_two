#!/usr/bin/env python
import rospy
from navigation.msg import nav_output

msg = nav_output()

def callback(msg):
    rospy.loginfo("x = %f",msg.x)
    rospy.loginfo("y = %f",msg.y)
    rospy.loginfo("orientation = %f",msg.orientation)


rospy.init_node('output_here', anonymous=True)
sub = rospy.Subscriber("output", nav_output, callback)
rospy.spin()
