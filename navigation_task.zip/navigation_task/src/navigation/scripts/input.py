#!/usr/bin/env python


import rospy
from std_msgs.msg import String
from navigation.msg import nav_input

msg = nav_input()
def talker():
    pub = rospy.Publisher('input', nav_input, queue_size=10)
    rospy.init_node('input', anonymous=True)
    rate = rospy.Rate(1)
    vel = input("Enter velocity= ")
    steering = input("Enter steering angle= ")
    msg.velocity = int(vel)
    msg.steering_angle = int(steering)
    while not rospy.is_shutdown():

        rospy.loginfo(msg)
        pub.publish(msg)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
